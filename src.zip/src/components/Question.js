import React, { Component } from 'react'
import { View } from 'react-native'
import SelectMultiple from 'react-native-select-multiple'

//const fruits = ['Apples', 'Oranges', 'Pears']
// --- OR ---
 const fruits = [
   { label: 'Apples', value: 'appls' },
   { label: 'Oranges', value: 'orngs' },
   { label: 'Pears', value: 'pears' }
 ]

export default class Question extends Component {
  state = { selectedFruits: fruits }
//this.setState({ selectedFruits: fruits });
//console.log('mulitple start checkbox ', this.state.selectedFruits);
  onSelectionsChange = (selectedFruits) => {
    // selectedFruits is array of { label, value }
    console.log('value checkbox ', selectedFruits)
    this.setState({ selectedFruits })
    console.log('mulitple checkbox ',this.state.selectedFruits)
  }

  render () {
    return (
      <View style={{flex: 1, flexDirection: 'row-reverse'}}>
              <View style={{width: 50, height: 50, backgroundColor: 'powderblue'}} />
              <View style={{width: 50, height: 50, backgroundColor: 'skyblue'}} />
              <View style={{width: 50, height: 50, backgroundColor: 'steelblue'}} />
            </View>
    )
  }
}
