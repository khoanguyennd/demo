import React, { PureComponent } from 'react';
import { View, Text, StyleSheet, AsyncStorage, TouchableOpacity, Image } from 'react-native';
import { Header } from 'react-native-elements';
import { Left, Right} from 'native-base';
import { ActivityIndicator, FlatList } from 'react-native';
import {Modal, TouchableHighlight, CheckBox, TextInput, Button, ScrollView, Dimensions } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Pagination from 'react-native-pagination';
import {List, ListItem, SearchBar} from "react-native-elements";
//import { DataTable, DataTableCell, DataTableRow, DataTablePagination } from 'material-bread';
import { DataTable } from 'react-native-paper';
import SelectMultiple from 'react-native-select-multiple';
import { data } from './define';
//import { SelectMultipleGroupButton } from "../../index.js";
//import { SelectMultipleButton } from '../../libraries/SelectMultipleButton';
//import SimpleButton from "../../sample/SimpleButton";


import _ from "lodash";
import { SelectMultipleButton } from "../../index.js";

const multipleData = ["running ", "riding", "reading", "coding", "Niuer"];

const SCREEN_WIDTH = Dimensions.get("window").width;
const ios_blue = "#007AFF";
const themeColor = "#0D1014";
const server = data[0];

export default class TabOrderAll extends PureComponent {
      static navigationOptions = {
           title: 'Quản lý đơn hàng',
           headerStyle: {
             color: '#DB4437'
           },
           headerTintColor: '#DB4437',
           headerTitleStyle: {
              fontWeight: 'bold',
           },
      };

    constructor(props) {
         super(props);
         let date = new Date().getDate(); //To get the Current Date
         let month = new Date().getMonth() + 1; //To get the Current Month
         let year = new Date().getFullYear(); //To get the Current Year
         month = month >= 10 ? month: '0' + month;
         this.state = {
           loading: false,
           page: 1,
           perPage: 50,
           totalRow: 0,
           dataApi: [],
           statusDetail: [],
           channelAPI: [],
           nccAPI: [],
           isLoading: true,
           username: "",
           date:  new Date().getSeconds(),
           isSelected: false,
           refreshing: false,
           datasearch: [],
           searchtext: '',
           searchAll: '필터',
           toDay: year + '-' + month + '-' + date,
           fromDay: year + '-' + month + '-' + date,
           days: ["jan","feb","Mar"],
           modalVisible: false,
           detaiModalVisible: false,
           usageScrollView: null,
           multipleSelectedData: [],
           multipleSelectedDataLimited: [],
           multipleSelectedDataDetail: [],
           multipleSelectedDataDetailLimited: [],
           multipleSelectedDataNCC: [],
           multipleSelectedDataNCCLimited: [],
           delElementDetail: '',
           delElementNCC: '',
           selectedAllCheckbox: []
         };

         this.loadPagination = this.loadPagination.bind();
         this.loadMoreOrderAPI = this.loadMoreOrderAPI.bind();
         this.loadChannelAPI = this.loadChannelAPI.bind();
         this.loadChannelAPI1 = this.loadChannelAPI1.bind();
         this.submitSetting = this.submitSetting.bind();
         //this.toggleModal = this.toggleModal.bind();
    }


    componentDidMount() { //auto run function
           //console.log('method: ', this.props.method); // Get method api

           // get session
           AsyncStorage.getItem('accountshopping', (err, result) => {

                       //console.log('user', result);

                       this.setState({loading: true});
                       fetch(server+'orderApi.html', {
                               method: 'POST',
                               headers: {
                                 Accept: 'application/json',
                                 'Content-Type': 'application/json',
                               },
                               body: JSON.stringify({
                                  account_idx: JSON.parse(result).account_idx,
                                  account_ID: JSON.parse(result).account_ID,
                                  account_role: JSON.parse(result).account_role,
                                  method: this.props.method,
                                  page : this.state.page,
                                  datasearch : this.state.datasearch
                               }),
                             })
                        .then((response) => response.json())
                        .then((responseJson) => {
                            //console.log(this.state.datasearch);
                            console.log('zo ', responseJson);
                            if (responseJson.result) {
                                // console.log('page mount', this.state.page);
                                // console.log('ticket number', responseJson.list_order.data[0].ticketNumber);
                                this.setState({ dataApi: responseJson.list_order.data ,
                                                totalRow: responseJson.list_order.count,
                                                loading: false,
                                                refreshing: false });
                                 //this.setState({dataApi: this.state.page === 1 ? responseJson.list_order.data : [...this.state.dataApi, ...responseJson.list_order.data], totalRow: responseJson.list_order.count, loading: false,  refreshing: false });
                            }
                        })
                        .catch((error) => this.setState({loading: false}))
                        .finally(() => {
                             this.setState({ isLoading: false });
                        });

           });
     }

     submitSearch(event) {
        //console.log('searchtext', this.state.searchtext);

       let search= {
            "text_ten_phone_mave" : this.state.searchtext,
            "thoigian" : "0_2019-08-13_2020-08-13",
            "checked_kenh" : "all",
            "check_ncc" : 'all'
            };
        this.setState({datasearch: search});

        //  console.log('search find ', search);
        //this.setState({date: new Date().getSeconds()});
        this.setState(
             {
                 datasearch: search,
                 date: new Date().getSeconds()
             },
             () => {
                 //console.log('search find ', this.state.datasearch);
                 this.componentDidMount();
             }
         );
     }

    submitModalSearch(event) {
//        multipleSelectedData: [],
//                   multipleSelectedDataLimited: [],
//                   multipleSelectedDataDetail: [],
//                   multipleSelectedDataDetailLimited: [],
//                   multipleSelectedDataNCC: [],
//                   multipleSelectedDataNCCLimited: [],
//        console.log('multipleSelectedDataDetailLimited    ' , this.state.multipleSelectedDataDetailLimited);
//        console.log('multipleSelectedDataLimited ' , this.state.multipleSelectedDataLimited);
//        console.log('multipleSelectedDataNCCLimited ' , this.state.multipleSelectedDataNCCLimited);
        let searchAll = '';
        let daySearch = '0_2019-08-13_2020-08-13';
        if (this.state.multipleSelectedDataDetailLimited.length > 0) {

              // detail

            switch (this.state.multipleSelectedDataDetailLimited[0]) {
             case 'tất cả':
                   daySearch = '0_2019-08-13_2020-08-13';
                   searchAll += '#tất cả';
                   break;
              case 'hôm qua':
                   daySearch = '1_2019-08-13_2020-08-13';
                   searchAll += '#hôm qua';
                   break;
              case 'hôm nay':
                    daySearch = '2_2019-08-13_2020-08-13';
                    searchAll += '#hôm nay';
                    break;
              case '7 ngày qua':
                    daySearch = '3_2019-08-13_2020-08-13';
                    searchAll += '#7 ngày qua';
                    break;
              case '1 tháng trước':
                    daySearch = '4_2019-08-13_2020-08-13';
                    searchAll += '#1 tháng trước';
                    break;
              case '3 tháng qua':
                    daySearch = '5_2019-08-13_2020-08-13';
                    searchAll += '#3 tháng qua';
                    break;
              case '6 tháng qua':
                    daySearch = '6_2019-08-13_2020-08-13';
                    searchAll += '#6 tháng qua';
                    break;
              case 'Nhập trực tiếp':
                   daySearch = '7_' + this.state.toDay + '_' + this.state.fromDay;
                   searchAll += '#Nhập trực tiếp';
                   break;
              default :
                    return null;

            }
        }

        //console.log('detail ', daySearch);
        // channel
        let channelModalSerach = 'all';
        if (this.state.multipleSelectedDataLimited.length > 0 && this.state.multipleSelectedDataLimited[0] !== 'tất cả' && this.state.multipleSelectedDataLimited[this.state.multipleSelectedDataLimited.length -1] !== 'tất cả') {
            channelModalSerach = '';
            for (let i =0 ; i < this.state.multipleSelectedDataLimited.length; i += 1) {
                channelModalSerach += this.state.multipleSelectedDataLimited[i] + '_';
            }
        }

        searchAll += '#' + channelModalSerach;

        //console.log('chan ', channelModalSerach);

        // NCC

        let nccModalSerach = 'all';

        if (this.state.multipleSelectedDataNCCLimited.length > 0 && this.state.multipleSelectedDataNCCLimited[0] !== 'all') {
              nccModalSerach = this.state.multipleSelectedDataNCCLimited[0];
        }

        searchAll += '#' + nccModalSerach;
        this.setState({searchAll: searchAll});
        //console.log('ncc ', nccModalSerach);
        this.setState({ modalVisible: false });

        let search= {
            "text_ten_phone_mave" : '',
            "thoigian" : daySearch,
            "checked_kenh" : channelModalSerach,
            "check_ncc" : nccModalSerach
            };
        this.setState({datasearch: search});
        this.setState(
             {
                 datasearch: search,
                 date: new Date().getSeconds()
             },
             () => {
                 //console.log('search find ', this.state.datasearch);
                 this.componentDidMount();
             }
         );
    }

    loadMoreOrderAPI = (page) => {

             this.setState(
                 {
                     page: page
                 },
                 () => {

                     this.componentDidMount();
                 }
             );

     };



     loadPagination = () => {
        let totalPage = Math.floor(this.state.totalRow / this.state.perPage);
        let dataPagination = [];
        let dataPaginationPre = [];
        let dataPaginationNext = [];
        // getPrePage

        if (this.state.page != 1) {
            dataPaginationPre.push(this.state.page -1);
        }

        // getNextPage
        if (this.state.page < totalPage) {
            dataPaginationNext.push(this.state.page + 1);
        }

        // get pagination
        // for (let i = (this.state.page - 4) > 0 ? (this.state.page - 4) : 1; i <= ((this.state.page + 4) > totalPage ? totalPage : (this.state.page + 4)); i += 1) {
        for (let i = this.state.page; i <= ((this.state.page + 4) > totalPage ? totalPage : (this.state.page + 4)); i += 1) {
            dataPagination.push(i);
        }

        return (
           <View style={{flex: 1, flexDirection: 'row'}}>
            {

                dataPaginationPre.map((item, index) => <View style={this.state.page == item ? styles.buttonPaginationActive : styles.buttonPagination} >
                                                <TouchableOpacity activeOpacity={0.95} onPress={() => this.loadMoreOrderAPI(item)} >
                                                    <Text > {"<"} </Text>
                                                </TouchableOpacity>
                                             </View>
                                     )
            }

            {

              dataPagination.map((item, index) => <View style={this.state.page == item ? styles.buttonPaginationActive : styles.buttonPagination} >
                                            <TouchableOpacity activeOpacity={0.95} onPress={() => this.loadMoreOrderAPI(item)} >
                                                <Text >{item}</Text>
                                            </TouchableOpacity>
                                         </View>
                                 )
            }

            {

                dataPaginationNext.map((item, index) => <View style={this.state.page == item ? styles.buttonPaginationActive : styles.buttonPagination} >
                                                <TouchableOpacity activeOpacity={0.95} onPress={() => this.loadMoreOrderAPI(item)} >
                                                    <Text > {">"} </Text>
                                                </TouchableOpacity>
                                             </View>
                                     )
            }
            </View>
        )
   };

    loadChannelAPI = () => {
        AsyncStorage.getItem('accountshopping', (err, result) => {
                   //console.log('user', result);
                   fetch(server+'channelApi.html', {
                           method: 'POST',
                           headers: {
                             Accept: 'application/json',
                             'Content-Type': 'application/json',
                           },
                           body: JSON.stringify({
                              account_idx: JSON.parse(result).account_idx,
                              account_ID: JSON.parse(result).account_ID,
                              account_role: JSON.parse(result).account_role
                           }),
                         })
                    .then((response) => response.json())
                    .then((responseJson) => {
                        //console.log('channel', responseJson);
                        if (responseJson.result) {
                        let dataChannel = responseJson.data;
                            dataChannel.unshift('tất cả');
//                            responseJson.data.map( item => {
//                                //console.log('hello');
//                              console.log('hello', item);
//                           });
                            this.setState({ channelAPI: dataChannel});
                            for (let i = 0 ; i < this.state.channelAPI.length ; i ++) {
                                this.state.multipleSelectedDataLimited.push(this.state.channelAPI[i]);
                             }
                        }
                    })
                    .catch((error) => console.log(error))
                    .finally(() => {
                         this.setState({ isLoading: false });
                    });
       });
    }

    loadNCCAPI = () => {
        AsyncStorage.getItem('accountshopping', (err, result) => {
                   //console.log('user', result);
                   fetch(server+'nccApi.html', {
                           method: 'POST',
                           headers: {
                             Accept: 'application/json',
                             'Content-Type': 'application/json',
                           },
                           body: JSON.stringify({
                              account_idx: JSON.parse(result).account_idx,
                              account_ID: JSON.parse(result).account_ID,
                              account_role: JSON.parse(result).account_role
                           }),
                         })
                    .then((response) => response.json())
                    .then((responseJson) => {
                        //console.log('NCC', responseJson);
                        if (responseJson.result) {
                            //let dataNCC = [];
                            //dataNCC.push('tất cả');
                            //dataNCC = responseJson.data;
                            this.setState({ nccAPI: responseJson.data});

                        }
                    })
                    .catch((error) => console.log(error))
                    .finally(() => {
                         this.setState({ isLoading: false });
                    });
       });
    }

    toggleModal(visible) {
      let statusDetail  =  [
      'tất cả',
      'hôm qua',
      'hôm nay',
      '7 ngày qua',
      '1 tháng trước',
      '3 tháng qua',
      '6 tháng qua',
      'Nhập trực tiếp'
      ];

      this.setState({statusDetail: statusDetail});
      this.state.multipleSelectedDataDetailLimited.push('tất cả');
      //this.state.multipleSelectedDataLimited.push('tất cả');
      this.state.multipleSelectedDataNCCLimited.push('all');
      this.loadChannelAPI();
      this.loadNCCAPI();
      this.setState({ modalVisible: visible });
    }

     closeModal(visible) {
       this.setState({ modalVisible: visible });
    };
    submitSetting = () => {
        while(this.state.multipleSelectedDataDetailLimited.length>0){
            this.state.multipleSelectedDataDetailLimited.pop();
        }

         while(this.state.multipleSelectedDataLimited.length>0){
            this.state.multipleSelectedDataLimited.pop();
         }

         while(this.state.multipleSelectedDataNCCLimited.length>0){
             this.state.multipleSelectedDataNCCLimited.pop();
          }

        // this.setState({multipleSelectedDataNCCLimited: this.state.multipleSelectedDataNCCLimited});
        this.setState({date: new Date().getSeconds()});

    };
     // selected detail
     _singleTapMultipleSelectedButtonsDetail(interest) {

             if (this.state.multipleSelectedDataDetail.includes(interest)) {
               _.remove(this.state.multipleSelectedDataDetail, ele => {
                 return ele === interest;
               });
             } else {

               this.state.multipleSelectedDataDetail.push(interest);
             }

             this.setState({
               multipleSelectedDataDetail: this.state.multipleSelectedDataDetail
             });
         }

         _singleTapMultipleSelectedButtonsDetail_limited(interest) {

             if (this.state.multipleSelectedDataDetailLimited.includes(interest)) {
               _.remove(this.state.multipleSelectedDataDetailLimited, ele => {
                 return ele === interest;
               });
               //this.setState({detaiModalVisible: false});
               //console.log('select del detail ', this.state.multipleSelectedDataDetailLimited);
               this.setState({date: new Date().getSeconds()});
             } else {

                 // remove previous element

                 //if (this.state.multipleSelectedDataDetailLimited.length > 0) {
                      //console.log('xoa: ', this.state.multipleSelectedDataDetailLimited[0]);

                     _.remove(this.state.multipleSelectedDataDetailLimited, ele => {
                        this.setState({delElementDetail: this.state.multipleSelectedDataDetailLimited[0]});
                        return ele === this.state.multipleSelectedDataDetailLimited[0];
                     });
                // }

                 //console.log('sau khi xoa: ', this.state.multipleSelectedDataDetailLimited);
                 this.state.multipleSelectedDataDetailLimited.push(interest);
                 if ( this.state.multipleSelectedDataDetailLimited[0] === 'Nhập trực tiếp') {
                    this.setState({detaiModalVisible: true});
                 }else {
                    this.setState({detaiModalVisible: false});
                 }
                 //console.log('select in detail ', this.state.multipleSelectedDataDetailLimited);
                 this.setState({date: new Date().getSeconds()});
             }

             this.setState({
               multipleSelectedDataDetailLimited: this.state.multipleSelectedDataDetailLimited
             });

         }

    // selected channel
    _singleTapMultipleSelectedButtons(interest) {

        if (this.state.multipleSelectedData.includes(interest)) {
          _.remove(this.state.multipleSelectedData, ele => {
          //console.log('zo  ', interest);
            return ele === interest;
          });
        } else {
            //console.log('zo he ', interest);
          this.state.multipleSelectedData.push(interest);
        }

        this.setState({
          multipleSelectedData: this.state.multipleSelectedData
        });
    }

    _singleTapMultipleSelectedButtons_limited(interest) {
        //console.log('interest  ',interest);
        //console.log('multipleSelectedDataLimited in', this.state.multipleSelectedDataLimited);
        if (this.state.multipleSelectedDataLimited.includes(interest)) {
            if (interest === 'tất cả') {
                while(this.state.multipleSelectedDataLimited.length>0){
                    this.state.multipleSelectedDataLimited.pop();
                }
            }else{
                let index = this.state.multipleSelectedDataLimited.indexOf(interest);
                if (index > -1) {
                  this.state.multipleSelectedDataLimited.splice(index, 1);
                  let index1 = this.state.multipleSelectedDataLimited.indexOf('tất cả');
                  if (index1 > -1) {
                    this.state.multipleSelectedDataLimited.splice(index1, 1);
                  }
                }
            }

          this.setState({date: new Date().getSeconds()});

        } else {
          //if (this.state.multipleSelectedDataLimited.length < 3)
          if (interest === 'tất cả') {
                while(this.state.multipleSelectedDataLimited.length>0){
                       this.state.multipleSelectedDataLimited.pop();
                }

                for (let i = 0 ; i < this.state.channelAPI.length ; i ++) {
                    this.state.multipleSelectedDataLimited.push(this.state.channelAPI[i]);
                }
                this.setState({date: new Date().getSeconds()});
                //
                let j = 0;
          }else {

                this.state.multipleSelectedDataLimited.push(interest);
                let j=0;
                for (let i = 0 ; i < this.state.channelAPI.length ; i ++) {
                    if (this.state.multipleSelectedDataLimited.includes(this.state.channelAPI[i]))
                        j++;
                }
                if(j==(this.state.channelAPI.length-1))
                    this.state.multipleSelectedDataLimited.push('tất cả');
                this.setState({date: new Date().getSeconds()});

          }

        }

        this.loadChannelAPI1.bind();

    }
    loadChannelAPI1 = () => {
            //console.log("loadChannelAPI 1 ",this.state.multipleSelectedDataLimited);
            return (
             <View style={{flexWrap: "wrap", flexDirection: 'row'}}>

                     {

                         this.state.channelAPI.map(interest => (
                            <SelectMultipleButton
                              key={interest}
                              buttonViewStyle={{

                                height: 46
                              }}
                              textStyle={{
                                fontSize: 12
                              }}

                              highLightStyle={{
                                borderColor: "gray",
                                backgroundColor: "transparent",
                                textColor: "gray"
                              }}

                              value={interest}
                              selected={this.state.multipleSelectedDataLimited.includes(
                                interest
                              )}
                              singleTap={valueTap =>
                                this._singleTapMultipleSelectedButtons_limited(interest)
                              }
                            />
                        ))
                    }
                    </View>

             )
    }
    // selected NCC
     _singleTapMultipleSelectedButtonsNCC(interest) {

             if (this.state.multipleSelectedDataNCC.includes(interest)) {
               _.remove(this.state.multipleSelectedDataNCC, ele => {
                 return ele === interest;
               });
             } else {

               this.state.multipleSelectedDataNCC.push(interest);
             }

             this.setState({
               multipleSelectedDataNCC: this.state.multipleSelectedDataNCC
             });
         }

         _singleTapMultipleSelectedButtonsNCC_limited(interest) {

             if (this.state.multipleSelectedDataNCCLimited.includes(interest)) {
               _.remove(this.state.multipleSelectedDataNCCLimited, ele => {
                 return ele === interest;
               });
               //console.log('select del NCC ', this.state.multipleSelectedDataNCCLimited);
               this.setState({date: new Date().getSeconds()});

             } else {
               //if (this.state.multipleSelectedDataNCCLimited.length < 1)
                 _.remove(this.state.multipleSelectedDataNCCLimited, ele => {
                     this.setState({delElementDetail: this.state.multipleSelectedDataNCCLimited[0]});
                     return ele === this.state.multipleSelectedDataNCCLimited[0];
                  });
                 this.state.multipleSelectedDataNCCLimited.push(interest);
                 console.log('select in NCC', this.state.multipleSelectedDataNCCLimited);
                 this.setState({date: new Date().getSeconds()});
             }

             this.setState({
               multipleSelectedDataNCCLimited: this.state.multipleSelectedDataNCCLimited
             });

         }

     submitSelectedAllCheckbox(event) {
     }

      onSelectionsChange = (selectedAllCheckbox) => {
        // selectedFruits is array of { label, value }
        //console.log('value checkbox ', selectedFruits)
        this.setState({ selectedAllCheckbox })
        console.log('mulitple checkbox ',this.state.selectedAllCheckbox)
     }

    render () {
        const { navigation } = this.props;

        return (

            <View style={styles.container}>
                <View style={{ borderColor: '#ccc', backgroundColor: '#f2f2f2', borderWidth: 1 }}>
                    <View style={{height:50,  paddingTop:15, left: 20}}>
                       <View style={{flex: 1, flexDirection: 'row'}}>
                           <View style={{width: '79%'}} >
                               <TouchableOpacity activeOpacity={0.95}>
                                  <TextInput style={{borderWidth: 0.5, borderColor: '#607D8B', backgroundColor: '#fff'}} value={this.state.searchtext}
                                       onChangeText={searchtext =>
                                           this.setState({ searchtext })
                                       }
                                       ref={input => {
                                           this.textInput = input;
                                       }}  placeholder="홍길동 (name)"/>
                               </TouchableOpacity>
                           </View>
                       </View>
                    </View>
                    <View style={{height: 50,  paddingTop:10, left: 20}}>
                       <View style={{flex: 1, flexDirection: 'row'}}>
                           <View style={{width: '79%', bottom: 5}} >
                               <TouchableOpacity activeOpacity={0.95} onPress = {() => {this.toggleModal(true)}}>
                                  <TextInput style={{borderWidth: 0.5, borderColor: '#607D8B', backgroundColor: '#f2f2f2', textAlign: 'center'}} value={this.state.searchAll}  editable={false} />
                               </TouchableOpacity>
                           </View>
                       </View>
                    </View>
                </View>
                <View style={{width: 45,  position: 'absolute', right: 72, top: 27}}>
                    <Icon.Button style={{ backgroundColor: '#DB4437', height: 28}}
                       name='search'
                        onPress={this.submitSearch.bind(this)}
                    >
                    </Icon.Button>
                </View>
                <View style={{  position: 'absolute', right: 76, top: 72}}>
                    <TouchableOpacity onPress = {() => {this.toggleModal(true)}}>
                        <Image source={require('../../assets/ic_boloc.png')} style={{ height: 20, width: 25 }} />
                    </TouchableOpacity>
                </View>
                <View style= {{ width: '100%', top: 10 }}>
                    <View style={{flex: 1, flexDirection: 'row-reverse'}}>
                          <View style={{width: '30%', height: 40, backgroundColor: '#DB4437', alignItems: 'center', justifyContent: 'center'}} >
                                <TouchableOpacity activeOpacity={0.95}  onPress={this.submitSelectedAllCheckbox.bind(this)} >
                                    <Text style={{color: '#fff'}}>Xử lý phục hồi</Text>
                               </TouchableOpacity>
                          </View>
                          <View style={{width: '30%', height: 40, backgroundColor: '#DB4437', marginRight: 5, alignItems: 'center', justifyContent: 'center'}} >
                              <TouchableOpacity activeOpacity={0.95} onPress={this.submitSelectedAllCheckbox.bind(this)} >
                                  <Text style={{color: '#fff'}}>Sử dụng điều trị</Text>
                             </TouchableOpacity>
                          </View>
                          <View style={{width: '25%', height: 40, backgroundColor: '#f2f2f2', marginRight : 5, alignItems: 'center', justifyContent: 'center'}} >
                                <TouchableOpacity activeOpacity={0.95} onPress={this.submitSelectedAllCheckbox.bind(this)} >
                                    <Text style={{}}>Chọn tất cả</Text>
                               </TouchableOpacity>
                          </View>
                    </View>
                </View>

               <View style= {{ alignItems: 'center', width: '100%', top: 60 }}>
                {this.state.isLoading ? <ActivityIndicator size = "large"/> : (
                     <FlatList
                          data={this.state.dataApi}
                          keyExtractor={({ id }, index) => id}
                          renderItem={({ item, index }) => (

                          <View style= {styles.contentOrder}>
                              <View style={{flex: 1, flexDirection: 'row'}}>
                                 <View style={styles.contentOrderLeft}>
                                    <View>
                                        <Text style={styles.textPurcharse}>
                                        {item.statusTicket == -1? 'Hết hiệu lực' : item.statusTicket == 1? 'Mua xong'
                                            : item.statusTicket == 2? 'Đã sử dụng' : item.statusTicket == 3? 'Hết hạn sử dung'
                                            : item.statusTicket == 4? 'Hoàn tiền' : 'Hết hạn hoàn tiền'}
                                        </Text>
                                    </View>
                                    <View style={{ padding: '20%'}}>
                                        <CheckBox
                                          value={this.state.isSelected}
                                          style={styles.checkbox}
                                         />
                                    </View>
                                 </View>
                                 <View style={styles.contentOrderRight}>
                                    <Text style={styles.textbold}>T-Bridge: {item.ticketNumber}</Text>
                                    <Text style={styles.textbold}>Gmarket: {item.travelProductId}</Text>
                                    <View style={{marginTop: 10}}>
                                        <Text> {item.dealName}</Text>
                                        <Text> {item.price}M [{item.name}]</Text>
                                        <Text> {item.userName} [{item.phoneNumber}]</Text>
                                        <Text> Ngày mua: [{item.purchaseDateTime}]</Text>
                                    </View>
                                 </View>
                              </View>
                        </View>
                    )}

                 />

             )}
                </View>
                <View style={{ width: '100%', height: 35, marginTop:10,  alignItems: 'center', justifyContent: 'center'}}>
                      {this.loadPagination()}
                </View>
                <Modal animationType = {"slide"} transparent = {false}
                   visible = {this.state.modalVisible}
                   style={{width: '100%', backgroundColor: 'rgba(0,0,0,0.4)'}}
                   onRequestClose = {() => { console.log("Modal has been closed.") } }>
                   <ScrollView>
                   <View style={{height:60,  paddingTop:15, left: 20, bottom: 15}}>
                       <View style={{flex: 1, flexDirection: 'row', top: 10, left: 20, width: '100%'}}>
                           <View style={{alignItems: 'center', justifyContent: 'center', width: 50, height: 30, right: 10, backgroundColor: '#fdeada', borderColor: '#c00000', borderWidth: 1}}>
                               <TouchableHighlight onPress = {() => {
                                    this.submitSetting()}}>
                                    <Text style = {{alignItems: 'center', justifyContent: 'center', color: '#c00000'}}>Đặt lại </Text>
                               </TouchableHighlight>
                           </View>
                           <View style={{width: '70%', padding: 2}}><Text style={styles.textTitleModal}>tình trạng chi tiết</Text></View>
                           <View style={{alignItems: 'center', justifyContent: 'center', width: 50, height: 30, right: 20}}>
                              <TouchableHighlight onPress = {() => {
                                   this.closeModal(!this.state.modalVisible)}}>
                                   <Text style = {{alignItems: 'center', justifyContent: 'center', color: '#6d6767ad', fontSize: 22, cursor: 'pointer', textShadow: '#6d6767ad'}}>X </Text>
                              </TouchableHighlight>
                           </View>
                       </View>
                   </View>
                   <View style={{ width: '100%', paddingTop: 10}}>
                        <Text style={styles.textTitleModal}>Điều tra kỳ</Text>
                   </View>
                   <View style={{ left: 2}}>
                        {this.state.isLoading ? <ActivityIndicator size = "large"/> : (
                        <View
                              style={{
                                flexWrap: "wrap",
                                flexDirection: "row",
                              }}
                         >
                            {this.state.statusDetail.map(interest => (
                                <SelectMultipleButton
                                  key={interest}
                                  buttonViewStyle={{
                                    height: 46,
                                  }}
                                  textStyle={{
                                    fontSize: 12
                                  }}
                                  highLightStyle={{
                                    borderColor: "gray",
                                    backgroundColor: "transparent",
                                    textColor: "gray"
                                  }}

                                  value={interest}
                                  selected={this.state.multipleSelectedDataDetailLimited.includes(
                                    interest
                                  )}
                                  singleTap={valueTap =>
                                    this._singleTapMultipleSelectedButtonsDetail_limited(interest)
                                  }

                                />
                              ))}
                        </View>
                     )}
                       { this.state.detaiModalVisible &&
                        <View style={{flex: 1, flexDirection: 'row', width: '100%', top: 5, left: 2}}>
                            <View style={{ width: '45%'}}>
                               <Text style={{fontSize: 16}}>Đầu vào trực tiếp của kỳ</Text>
                            </View>
                            <View style={{width: '25%'}}>
                               <TouchableOpacity activeOpacity={0.95}>
                                     <TextInput style={{borderWidth: 0.5, borderColor: '#607D8B', backgroundColor: '#fff', paddingLeft: 4}} value={this.state.toDay}
                                          onChangeText={toDay =>
                                              this.setState({ toDay })
                                          }
                                          ref={input => {
                                              this.textInput = input;
                                          }} />
                               </TouchableOpacity>
                            </View>
                            <View style={{width: '25%', left: 5}}>
                               <TouchableOpacity activeOpacity={0.95}>
                                     <TextInput style={{borderWidth: 0.5, borderColor: '#607D8B', backgroundColor: '#fff', paddingLeft: 4}} value={this.state.fromDay}
                                          onChangeText={fromDay =>
                                              this.setState({ fromDay })
                                          }
                                          ref={input => {
                                              this.textInput = input;
                                          }} />
                               </TouchableOpacity>
                            </View>
                        </View>
                        }
                   </View>

                   <View style={{ width: '100%', paddingTop: 20}}>
                       <Text style={styles.textTitleModal}>Kênh (có thể có nhiều lựa chọn)</Text>
                   </View>

                   <View style={{  }}>
                       <View>
                         {this.state.isLoading ? <ActivityIndicator size = "large"/> : (
                            <View
                                  style={{
                                    flexWrap: "wrap",
                                    flexDirection: "row",
                                  }}
                             >
                                {this.loadChannelAPI1()}
                            </View>
                         )}

                       </View>
                   </View>
                   <View style={{ width: '100%', paddingTop: 20}}>
                       <Text style={styles.textTitleModal}>Công ty cơ sở</Text>
                   </View>
                   <View style={{  left: 2}}>
                                           {this.state.isLoading ? <ActivityIndicator size = "large"/> : (
                                           <View
                                                 style={{
                                                   flexWrap: "wrap",
                                                   flexDirection: "row",
                                                 }}
                                            >
                                               {this.state.nccAPI.map( item => (
                                                   <SelectMultipleButton
                                                     key={item.idx}
                                                     buttonViewStyle={{
                                                       height: 46,
                                                     }}
                                                     textStyle={{
                                                       fontSize: 12
                                                     }}
                                                     highLightStyle={{
                                                       borderColor: "gray",
                                                       backgroundColor: "transparent",
                                                       textColor: "gray"
                                                     }}
                                                     value={item.company}
                                                     selected={this.state.multipleSelectedDataNCCLimited.includes(
                                                       item.idx
                                                     )}
                                                     singleTap={valueTap =>
                                                       this._singleTapMultipleSelectedButtonsNCC_limited(item.idx)
                                                     }
                                                   />
                                                 ))}
                                           </View>
                                        )}

                                      </View>

                   <View style={{ width: '100%', height: 35, marginTop:10,  alignItems: 'center', justifyContent: 'center'}}>
                       <TouchableHighlight onPress = {this.submitModalSearch.bind(this)}>
                          <Button
                                  onPress = {this.submitModalSearch.bind(this)}
                                   title = "Ứng dụng"
                                   color = "#c00000"
                                />
                       </TouchableHighlight>
                   </View>

                  </ScrollView>
                </Modal>
            </View>
        );
    }
}

const styles = StyleSheet.create({
   container: { flex: 1, padding: 10, backgroundColor: '#fff' },
   usageTitle: {
       color: "white",
       marginTop: 20
    },
    horizontalView: {
       width: SCREEN_WIDTH
    },
    contentStyle: {

    },
   modal: {
     flex: 1,
     alignItems: 'center',
     backgroundColor: '#fefefe',
     padding: 10
   },
   textTitleModal: {
        fontSize: 20
   },
   textModalAll: {
       height: 45,
       alignItems: 'center',
       justifyContent: 'center',
       color: '#c00000',
       backgroundColor: '#fdeada', borderColor: '#c00000', borderWidth: 1, padding: 5, borderRadius: 3,  borderWidth: 1
   },
   textModal: {
      height: 45,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff', borderColor: '#a9a9a9', borderWidth: 1, padding: 5, borderRadius: 3,  borderWidth: 1
   },
   buttonModalAll: {
        width: '23.5%', height: 60, marginRight: 5
   },
   textbold: {fontWeight: 'bold'},
   textPurcharse: {width: '70%', color: '#fff', backgroundColor: '#3b5998'},
   buttonAllCheckBox: {
         width: 80,
         height: 40,
         alignItems: 'center',
         marginTop: 12,
         borderRadius: 5,
     },
     button: {
          width: 110,
          height: 40,
          backgroundColor: '#DB4437',
          alignItems: 'center',
          marginTop: 12,
          borderRadius: 5
      },
   contentOrder: {borderColor: '#ccc', borderWidth: 1, marginTop: 10, padding: 10 },
   contentOrderLeft: {width: '30%'},
   contentOrderRight: {width: '70%', left: 15 },
   buttonPagination: {
       fontSize: 12,
       backgroundColor: 'rgb(217, 217, 217)',
       marginLeft: 5,
       width: '9%',
       height: 30,
       borderColor: '#000',
       borderWidth: 0.5,
       alignItems: 'center',
       justifyContent: 'center'
   },
   buttonPaginationActive: {
          fontSize: 12,
          backgroundColor: '#DB4437',
          marginLeft: 5,
          width: '9%',
          height: 30,
          borderColor: '#000',
          borderWidth: 0.5,
          alignItems: 'center',
          justifyContent: 'center'
      },
   pagination: {
       backgroundColor: 'rgba(0,0,0,0)',
       width: 400,
       position: 'absolute',
       right: 0,
       left: 0,
       bottom: 7,
       padding: 0,
       flex: 1,
       justifyContent: 'center',
       alignItems: 'center',
       flexDirection: 'row'
    },
    containerMarginTop: {
      marginTop: 30
    },
    footerStyle:
      {
        padding: 7,
        alignItems: 'center',
        justifyContent: 'center',
        borderTopWidth: 2,
        borderColor: '#607D8B'
      },

      TouchableOpacity_style:
      {
        padding: 7,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F44336',
        borderRadius: 5,
      },

      TouchableOpacity_Inside_Text:
      {
        textAlign: 'center',
        color: '#fff',
        fontSize: 18
      },

      flatList_items:
      {
        fontSize: 20,
        color: '#000',
        padding: 10
      },
     welcome: {
      margin: 10,
      marginTop: 30,
      color: "gray"
    }

});
/*
 initialNumToRender={50}
                    maxToRenderPerBatch={8}
                    onEndReachedThreshold={4}
*/
//ListFooterComponent = { this.Render_Footer }
//<DataTable style={{backgroundColor: 'rgb(217, 217, 217)'}}>
//                  <DataTable.Pagination
//                    page={this.state.page}
//                    numberOfPages={Math.floor(this.state.totalRow / this.state.perPage)}
//                    onPageChange={page => this.loadMoreOrderAPI(page)}
//                    label={`${this.state.page * this.state.perPage}-${(this.state.page +1) * this.state.perPage} of ${this.state.totalRow}`}
//                  />
//                </DataTable>