export const data = [
   'http://tbridge.lavianspa.com/'  //server
];