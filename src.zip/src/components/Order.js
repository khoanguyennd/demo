import React , {PureComponent} from 'react';
import { View, Text, StyleSheet, Dimensions , ScrollView, AsyncStorage} from 'react-native';
import {TabViewAnimated, TabView, SceneMap, TabViewPage, TabBar } from 'react-native-tab-view';
import { Header } from 'react-native-elements';

import { ActivityIndicator, FlatList } from 'react-native';
import {  TextInput, Button } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import TabOrderAll from './TabOrderAll';

import { data } from './define';
const server = data[0];

//const initialLayout = { width: Dimensions.get('window').width, height: 1200 };

export default class Order extends PureComponent {

    static navigationOptions = {
           title: 'Quản lý đơn hàng',
           headerStyle: {
             color: '#DB4437'
           },
           headerTintColor: '#DB4437',
           headerTitleStyle: {
              fontWeight: 'bold',
           },
      };

    constructor(props) {
         super(props);
         this.state = {
                  index: -1,
                  routes: [
                              { key: 0, title: 'Toàn bộ' },
                              { key: 1, title: 'Mua xong' },
                              { key: 2, title: 'Sử dụng xong' },
                              { key: 3, title: 'Đang yêu cầu hoàn tiền' },
                              { key: 4, title: 'Hoàn tiền xong' },
                              { key: 5, title: 'Hết hạn sử dụng' }
                  ],

                };

         this.renderScene = this.renderScene.bind();
    }

    renderHeader = props => (
        <TabBar
          {...props}
          scrollEnabled
          indicatorStyle={styles.indicator}
          activeColor="#6d578b"
          inactiveColor="#c2c3c8"
          activeTintColor= 'blue'
          inactiveTintColor= 'grey'
          activeBackgroundColor = 'red'
          inactiveOpacity={0.5}
          activeOpacity={1.0}
          style={styles.tabbar}
          tabStyle={styles.tab}
          labelStyle={styles.label}
         />
      );

    renderScene = ({ route }) => {

                if (Math.abs(this.state.index - this.state.routes.indexOf(route)) == 0){
                    let method='';
                    switch (route.key) {
                      case 0:
                           method="";
                           break;
                      case 1:
                            method="done";
                            break;
                      case 2:
                            method="use";
                            break;
                      case 3:
                            method="unuse";
                            break;
                      case 4:
                            method="refundmoney";
                            break;
                      case 5:
                            method="die";
                            break;
                      default :
                            return null;

                    }
                    return <View style={[styles.scene, { backgroundColor: '#ffffff' }]} ><TabOrderAll method={method} /></View>;
                }

                if(this.state.index==-1)
                    this.setState({index:0 });
            };

    handleIndexChange = (index: number) => {
        this.setState({index, });
    }



  render() {

    return (
       <TabView
           navigationState={this.state}
           renderTabBar={this.renderHeader}
           renderHeader={this.renderHeader}
           renderScene={this.renderScene}
           onIndexChange={this.handleIndexChange}
           style={{flex: 1}}
       />
    );
  }

};

 const styles = StyleSheet.create({
 scene: {
     flex: 1,
   },
   navigationBarTitleStyle: {
       backgroundColor: '#DB4437',
       color: '#DB4437'
   },
  container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: '#fff' },
  header: { height: 50, backgroundColor: '#537791' },
  text: { textAlign: 'center', fontWeight: '100' },
  dataWrapper: { marginTop: -1 },
  row: { height: 40, backgroundColor: '#E7E6E1' },
  tabbar: {
      backgroundColor: '#fff', // mau nen tab
    },
    tab: {
      width: 170,
    },
    indicator: {
      backgroundColor: '#DB4437'  // mau gach bottom tab active
    },
    label: {
      color: '#000',  // mau chu text tab
      fontWeight: '400',
      fontSize: 11
    },
});

