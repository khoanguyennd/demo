import React, { Component } from 'react';
import { StyleSheet, ScrollView, AsyncStorage,ActivityIndicator, FlatList } from 'react-native';
import { View, Text, TextInput, Button, TouchableOpacity, Dimensions } from 'react-native';


//import { Table, TableWrapper, Row } from 'react-native-table-component';
import { DataTable } from 'react-native-paper';
import Cookie from 'react-native-cookie'; //npm install react-native-cookie --save
import { LineChart } from 'react-native-chart-kit' // npm i react-native-chart-kit --save  // npm i react-native-svg --save

import Icon from 'react-native-vector-icons/FontAwesome';

import { data } from './define';
const server = data[0];

let { height } = Dimensions.get('window');
let box_count = 3;
let box_height = height / box_count;
// line chart//////////////
const dataChart = {
  labels: ['January', 'February', 'March', 'April', 'May', 'June'],
  datasets: [
                {   data: [ 0, 0, 0, 0, 0, 0 ] ,
                    color: (opacity = 1) => `rgba(91, 177, 217, ${opacity})`, // optional
                    strokeWidth: 3, // optional
                },
                {   data: [ 10, 25, 68, 20, 79, 53 ] ,
                    color: (opacity = 1) => `rgba(253, 209, 0, ${opacity})`, // optional
                    strokeWidth: 3 , // optional
                },
            ],
  legend: ["Rainy Days" , 'weekend'] // optional
}
const screenWidth = Dimensions.get('window').width;
const chartConfig = {
  backgroundGradientFrom: "#1E2923",
  backgroundGradientFromOpacity: 0.8,
  backgroundGradientTo: "#08130D",
  backgroundGradientToOpacity: 0.5,
  color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
  labelColor: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
  strokeWidth: 3, // optional, default 3
  barPercentage: 10,
  useShadowColorFromDataset: false,// optional
  decimalPlaces: 0,
};
//////////////////

export default class Main extends Component {
  constructor(props) {
     super(props);
     this.state = {
       dataApi: [],
       isLoading: true,
       searchtext: "",
       username: "",
       account_idx : "aaa",
       account_ID : "aaa",
       account_role : "aaa"
     };
  }
  componentDidMount() { //auto run function
       // get session
       AsyncStorage.getItem('accountshopping', (err, result) => {
//             this.setState({ account_idx: JSON.parse(result).account_idx });
//             this.setState({ account_ID: JSON.parse(result).account_ID });
//             this.setState({ account_role: JSON.parse(result).account_role });
              var account = result;
              console.log(account);
              fetch(server+'dashboardApi.html', {
                   method: 'POST',
                   headers: {
                     Accept: 'application/json',
                     'Content-Type': 'application/json',
                   },
                   body: JSON.stringify({
                      account_idx: JSON.parse(result).account_idx,
                      account_ID: JSON.parse(result).account_ID,
                      account_role: JSON.parse(result).account_role
                   })
              })
              .then((response) => response.json())
              .then((responseJson) => {
                   console.log(responseJson);
                  if (responseJson.result) {
                       this.setState({ company_name: responseJson.company_name });
                       this.setState({ data1: responseJson.data1 });
                       this.setState({ data22: responseJson.data22 });
                       this.setState({ data33: responseJson.data33 });
                       this.setState({ data44: responseJson.data44 });
                       this.setState({ notifications: responseJson.notifications });
                       this.setState({ order_number: responseJson.order_number });
                       this.setState({ question_number: responseJson.question_number });
                       this.setState({ homqua_show: responseJson.homqua_show });
                       this.setState({ homnay_show: responseJson.homnay_show });
                       this.setState({ amountsoldrealtotal_homqua: responseJson.amountsoldrealtotal_homqua });
                       this.setState({ amountsoldrealtotal_homnay: responseJson.amountsoldrealtotal_homnay });
                       this.setState({ amountsoldusetotal_homqua: responseJson.amountsoldusetotal_homqua });
                       this.setState({ amountsoldusetotal_homnay: responseJson.amountsoldusetotal_homnay });
                       this.setState({ tong_muaxong_homqua: responseJson.tong_muaxong_homqua });
                       this.setState({ tong_muaxong_homnay: responseJson.tong_muaxong_homnay });
                       this.setState({ tong_sudung_homqua: responseJson.tong_sudung_homqua });
                       this.setState({ tong_sudung_homnay: responseJson.tong_sudung_homnay });
                  }
              })
              .catch((error) => {
                      console.log(error);
                      console.error(error);
                   })
              .finally(() => {
                   this.setState({ isLoading: false });
              });

       });
       //AsyncStorage.removeItem(SESSION_KEY);
  }

  render() {
     const { navigation } = this.props;
     const searchSubmit = () => {
        fetch(server+'orderApi.html')
           .then((response) => response.json())
           .then((responseJson) => {
               if (responseJson.result) {
                    console.log(responseJson.list_order);
                    this.setState({ dataApi: responseJson.list_order });
               }
           })
           .catch((error) => console.error(error))
           .finally(() => {
                this.setState({ isLoading: false });
           });
     };

    return (
        <ScrollView  style={styles.container}>

                <View style={{width: '100%', borderColor: '#000', borderWidth: 1, borderRadius: 5}}>
                    <View style={{height:50, borderBottom: "#ccc", borderBottomWidth: 1, paddingTop:15}}>
                       <View style={{flex: 1, flexDirection: 'row'}}>
                           <View style={{width: '20%'}} >
                               <Text style={{left: 10}}>{this.state.company_name} </Text>
                           </View>
                           <View style={{width: '79%', bottom: 5}} >
                               <TouchableOpacity activeOpacity={0.95}>
                                  <TextInput style={{borderColor: '#ccc', borderWidth: 1}} value={this.state.searchtext}
                                       onChangeText={searchtext =>
                                           this.setState({ searchtext })
                                       }
                                       ref={input => {
                                           this.textInput = input;
                                       }}  placeholder="홍길동 (name)"/>
                               </TouchableOpacity>
                           </View>
                       </View>
                    </View>
                    <View style= {{ alignItems: 'center', color: '#CCC' , height : 100 , marginTop: 10 }}>
                        <View style={{flex: 1, flexDirection: 'row'}}>
                            <View style={styles.textContentResult} >
                                <TouchableOpacity activeOpacity={0.95} onPress={() => {navigation.navigate('Order', { id: 100, title: 'hello' });}} >
                                    <Text style={styles.textResult}>{this.state.order_number} kết quả</Text>
                                    <Text style={{ fontWeight: 'bold'}}> Vé chưa sử dụng</Text>
                                    </TouchableOpacity>
                            </View>
                            <View style={styles.textContentResult} >
                                <TouchableOpacity activeOpacity={0.95} onPress={() => {navigation.navigate('Question', { id: 120 });}} >
                                    <Text style={styles.textResult}>{this.state.question_number} kết quả </Text>
                                    <Text style={{ fontWeight: 'bold'  }}> Câu hỏi chưa trả lời</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                    <View style= {{  color: '#CCC', margin: 10 }}>
                        <Text style={{fontSize: 16, fontWeight: 'bold', alignItems: 'center' }}>Tình hình bán vé</Text>
                    </View>
                    <View style={{ height: 1, width: '100%', borderRadius: 1, borderWidth: 0.5, borderColor: '#000' }}></View>
                                  <View style= {{  color: '#CCC' , height : 150, marginTop: 20 }}>
                                      <View style={{flex: 1, flexDirection: 'row'}}>
                                         <View style={[styles.boxTicket, styles.boxTicket3]}></View>
                                         <View style={[styles.boxTicket5, styles.boxTicket4]}><Text>Hôm qua {this.state.homqua_show}</Text></View>
                                         <View style={[styles.boxTicket5, styles.boxTicket4]}><Text>Hôm nay {this.state.homnay_show}</Text></View>
                                      </View>
                                      <View style={{flex: 1, flexDirection: 'row'}}>
                                          <View style={[styles.boxTicket, styles.boxTicket1]}><Text>Số tiền bán thực</Text></View>
                                          <View style={[styles.boxTicket5, styles.boxTicket2]}><Text>{this.state.amountsoldrealtotal_homqua}</Text></View>
                                          <View style={[styles.boxTicket5, styles.boxTicket2]}><Text>{this.state.amountsoldrealtotal_homnay}</Text></View>
                                      </View>
                                      <View style={{flex: 1, flexDirection: 'row'}}>
                                        <View style={[styles.boxTicket, styles.boxTicket1]}><Text>Số tiền xử lý sử dụng</Text></View>
                                        <View style={[styles.boxTicket5, styles.boxTicket2]}><Text>{this.state.amountsoldusetotal_homqua}</Text></View>
                                        <View style={[styles.boxTicket5, styles.boxTicket2]}><Text>{this.state.amountsoldusetotal_homnay}</Text></View>
                                      </View>
                                      <View style={{flex: 1, flexDirection: 'row'}}>
                                        <View style={[styles.boxTicket, styles.boxTicket1]}><Text>Số vé bán</Text></View>
                                        <View style={[styles.boxTicket5, styles.boxTicket2]}><Text>{this.state.tong_muaxong_homqua}</Text></View>
                                        <View style={[styles.boxTicket5, styles.boxTicket2]}><Text>{this.state.tong_muaxong_homnay}</Text></View>
                                      </View>
                                      <View style={{flex: 1, flexDirection: 'row'}}>
                                          <View style={[styles.boxTicket, styles.boxTicket1]}><Text>Số vé xử lý sử dụng</Text></View>
                                          <View style={[styles.boxTicket5, styles.boxTicket2]}><Text>{this.state.tong_sudung_homqua}</Text></View>
                                          <View style={[styles.boxTicket5, styles.boxTicket2]}><Text>{this.state.tong_sudung_homnay}</Text></View>
                                      </View>
                                </View>
                    <View style= {{padding: 10, width: '100%', alignItems: 'center', justifyContent: 'center', color: '#CCC'}}>
                       <LineChart
                         data={dataChart}
                         width={screenWidth-20}
                         height={220}
                         chartConfig={chartConfig}
                       />
                    </View>

                    <View style= {{padding: 10, width: '100%', alignItems: 'center', justifyContent: 'center', color: '#CCC'}}>
                       <LineChart
                         data={dataChart}
                         width={screenWidth-20}
                         height={220}
                         chartConfig={chartConfig}
                       />
                    </View>
                     <View style= {{padding: 10, width: '100%', alignItems: 'center', justifyContent: 'center', color: '#CCC'}}>
                                               <TouchableOpacity activeOpacity={0.95} style={styles.button} onPress={() => {navigation.navigate('Order');}} >
                                                   <Text style={styles.text}>Xem toàn bộ đơn hàng > </Text>
                                               </TouchableOpacity>
                                         </View>
                    <View style={{width: '22%',  position: 'absolute', right: 5, top: 10}}>
                        <Icon.Button style={{ backgroundColor: '#DB4437', height: 30}}
                           name='search'
                           onPress={searchSubmit}
                        >
                        </Icon.Button>
                    </View>
                </View>
            </ScrollView >

    );
  }

};

 const styles = StyleSheet.create({
  container: { flex: 1, padding: 5, paddingTop: 30, backgroundColor: '#fff' },
  header: { height: 50, backgroundColor: '#537791' },
  dataWrapper: { marginTop: -1 },
  row: { height: 40, backgroundColor: '#E7E6E1' },
  boxTicket: {
          height: 30,
          width: '40%',
          paddingTop: 4,
          paddingLeft:2
      },
      boxTicket5: {
          height: 30,
          width: '30%'
      },
      boxTicket1: {
          backgroundColor: '#ccc',
          borderColor: '#000',
          borderWidth: 0.5
      },
      boxTicket2: {
          borderColor: '#000',
          borderWidth: 0.5
      },
      boxTicket3: {
          backgroundColor: '#fff'
      },
      boxTicket4: {
      backgroundColor: '#CCC',
          borderColor: '#000',
          borderWidth: 0.5
      },
      parent: {
          width: 300,
          height: 500,
          backgroundColor: 'red',
          margin: 50,
      },
      button: {
          flexDirection: 'row',
          height: 50,
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: 52,
          color: '#DB4437',
          borderColor: '#DB4437',
          borderWidth: 1,
          borderRadius: 10,
          textDecorationLine: 'none',
          bottom: 30
      },
      text: {
          color: '#DB4437',
          fontSize: 16,
          fontWeight: 'bold',
          padding: 80
      },
      textContentResult: {
          marginLeft: 8,
          width: '46%',
          height: 100,
          borderColor: '#000',
          borderWidth: 0.5,
          alignItems: 'center',
          justifyContent: 'center'
      },
      textResult: {
          fontSize: 18,
          fontWeight: 'bold',
          textDecorationLine: 'underline',
          textDecorationStyle: 'solid',
          textDecorationColor: '#000'
      },
});
